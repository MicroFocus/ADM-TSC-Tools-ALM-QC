﻿Module SaaSTool
    Public filenamedate As String
    'Added the following function to improve logging
    Public Sub logMessage(ByRef message As String)
        On Error GoTo ErrorHandler
        FoldExists(AuthenticationForm.WorkingPath.Text)
        FileOpen(5, AuthenticationForm.WorkingPath.Text & "\Log_" & filenamedate & ".txt", OpenMode.Append)
        Print(5, Now & ": " & message & vbCrLf)
        FileClose(5)
        Exit Sub
ErrorHandler:
        MsgBox("Failed to open log file for editing.")
        MsgBox(Err.Description)
    End Sub
    'Added the following function to improve logging
    Public Sub writedata(ByRef message As String, filename As String)
        On Error GoTo ErrorHandler
        FoldExists(AuthenticationForm.WorkingPath.Text)
        FileOpen(5, filename, OpenMode.Output)
        Print(5, message & vbCrLf)
        FileClose(5)
        Exit Sub
ErrorHandler:
        MsgBox("Failed to open data file for editing.")
        MsgBox(Err.Description)
    End Sub
    Public Function FExists(ByRef OrigFile As String) As Object
        On Error GoTo ErrorHandler
        Dim fs As Object
        fs = CreateObject("Scripting.FileSystemObject")
        FExists = fs.fileexists(OrigFile)
        Exit Function
ErrorHandler:
        MsgBox("Failed to access the log.")
        MsgBox(Err.Description)
    End Function


    'This function checks if required folders exists and if not, will create the folder
    Public Sub FoldExists(ByRef Folder As String)
        On Error GoTo ErrorHandler
        Dim MyFileSystem As Object

        MyFileSystem = CreateObject("Scripting.FileSystemObject")

        If MyFileSystem.FolderExists(Folder) = False Then
            MyFileSystem.CreateFolder(Folder)
        End If
        MyFileSystem = Nothing

        GC.Collect()
        Exit Sub
ErrorHandler:
        MsgBox("Failed to access the log file directory.")
        MsgBox(Err.Description)
    End Sub
    'This fucntion delete a file
    Public Sub DeleteFile(ByRef filename As String)
        On Error GoTo ErrorHandler
        Dim MyFileSystem As Object
        MyFileSystem = CreateObject("Scripting.FileSystemObject")
        MyFileSystem.DeleteFile(filename)
        GC.Collect()
        Exit Sub
ErrorHandler:
        MsgBox("Failed to access the log file directory.")
        MsgBox(Err.Description)
    End Sub
    Public Sub GenerateExcel(filename As String)
        Dim fso As Object
        Dim oStream As Object
        Dim f As Object
        Dim row As Integer
        Dim col As Integer
        Dim strRecord As String
        Dim i As Integer
        Dim j As Integer
        Dim dataArray As Object
        Dim dataItem As Object
        Dim EA As Object
        Dim EB As Object
        Dim ES As Object
        EA = CreateObject("Excel.Application")
        EB = EA.Workbooks.Add
        ES = EB.Worksheets.Add

        'Start on the second row
        row = 1
        col = 1

        'Create the filesystemobject
        fso = CreateObject("Scripting.FileSystemObject")
        On Error Resume Next
        'Get the data text file
        f = fso.GetFile(filename)
        If Err.Number <> 0 Then

            Exit Sub
        End If
        oStream = f.OpenAsTextStream(1, -2)
        Do While Not oStream.AtEndOfStream
            strRecord = ""
            strRecord = oStream.ReadLine
            dataArray = Split(strRecord, ",")
            col = 1
            For Each dataItem In dataArray
                ES.cells(row, col).NumberFormat = "@"
                ES.cells(row, col) = dataItem
                col = col + 1
            Next
            row = row + 1
        Loop
        oStream.Close()


        ES.SaveAs(Replace(filename, ".txt", ".xlsx"))
        ES.Application.Quit()
        EA = Nothing
        EB = Nothing
        ES = Nothing
        Exit Sub

    End Sub

End Module
