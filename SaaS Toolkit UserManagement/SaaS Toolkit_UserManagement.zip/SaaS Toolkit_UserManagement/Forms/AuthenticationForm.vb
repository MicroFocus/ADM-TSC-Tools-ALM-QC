Option Strict Off
Option Explicit On
Friend Class AuthenticationForm
    Inherits System.Windows.Forms.Form
    Dim AllDomains As Boolean
    Dim AllProjects As Boolean
    Public tdc 'As New TDAPIOLELib.TDConnection
    Public SelectedProjectsList As New ListBox
    Dim cusername As String
    Dim cdomain As String
    Dim cproject As String
    Public comcl As Boolean
    Dim StrXml As String


    Private Sub AuthenticationForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AllDomains = False
        AllProjects = False

        EnableUserPassEntry(False)
        EnableDomainSelect(False)
        EnableProjectSelect(False)
        EnableTaskSelect(False)
        filenamedate = Format(Now, "ddMMyyyy_hhmmss")
        'UserList.Visible = False
    End Sub

    Private Sub AuthenticationForm_FormClosed(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

        If tdc Is Nothing Then
            Exit Sub
        End If

        If tdc.ProjectConnected Then
            tdc.DisconnectProject()
        End If
        tdc.ReleaseConnection()
        Exit Sub

    End Sub

    Private Sub InitServCommand_Click(sender As Object, e As EventArgs) Handles InitServCommand.Click
        On Error GoTo ErrorHandler
        Dim sMajorVersion As String
        Dim sMinorVersion As String


        ' Initialize connection to QC Server
        DisplayStatusMessage("Initializing QC Server...")
        tdc = CreateObject("TDApiOle80.TDConnection.1")
        If Not APIKeyCheckbox.Checked Then
            tdc.InitConnectionEx(ServerUrlText.Text)
        End If


        InitServCommand.Enabled = False
        ServerUrlText.Enabled = False
        RunCommand.Enabled = True
        DisplayStatusMessage("Please authenticate.")
        EnableUserPassEntry(True)
        EnableDomainSelect(False)
        EnableProjectSelect(False)
        EnableTaskSelect(False)

        Exit Sub
ErrorHandler:
        MsgBox("URL error: (" & ServerUrlText.Text & ") " & vbCrLf & Err.Description)
        DisplayStatusMessage("Ready")
        Exit Sub
    End Sub
    Private Sub EnableUserPassEntry(ByRef toEnable As Boolean)
        UserNameText.Enabled = toEnable
        UserPasswordText.Enabled = toEnable
        AuthenticateCommand.Enabled = toEnable
        APIKeyCheckbox.Enabled = toEnable
    End Sub

    Private Sub EnableDomainSelect(ByRef toEnable As Boolean)
        SelectAllDomainCheck.Enabled = toEnable
        DomainList.Enabled = toEnable
        SelectDomainCommand.Enabled = toEnable
    End Sub

    Private Sub EnableProjectSelect(ByRef toEnable As Boolean)
        SelectAllProjectCheck.Enabled = toEnable
        ProjectList.Enabled = toEnable
        SelectProjectCommand.Enabled = toEnable
    End Sub
    Private Sub EnableTaskSelect(ByRef toEnable As Boolean)
        RunCommand.Enabled = toEnable
        TasksList.Enabled = toEnable
        WorkingPath.Enabled = toEnable
    End Sub

    Private Sub SelectAllDomainCheck_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SelectAllDomainCheck.CheckStateChanged
        AllDomains = SelectAllDomainCheck.CheckState
        DomainList.Enabled = Not AllDomains
        SelectProjectCommand.Enabled = True
    End Sub

    Private Sub SelectAllProjectCheck_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SelectAllProjectCheck.CheckStateChanged
        AllProjects = SelectAllProjectCheck.CheckState
        ProjectList.Enabled = Not AllProjects
    End Sub
    Private Sub AuthenticateCommand_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles AuthenticateCommand.Click
        Dim mdomain As Object

        If UserNameText.Text = "" Then
            MsgBox("Please enter username")
            Exit Sub
        End If

        'Log on to server
        DisplayStatusMessage("Athenticating user")
        On Error GoTo Login_err
        If APIKeyCheckbox.Checked Then

            tdc.InitConnectionWithApiKeyEx(ServerUrlText.Text, UserNameText.Text, UserPasswordText.Text)
        Else
            tdc.Login(UserNameText.Text, UserPasswordText.Text)
        End If

        DisplayStatusMessage("User athenticated")

        For Each mdomain In tdc.VisibleDomains
            DomainList.Items.Add(mdomain)
        Next mdomain

        EnableUserPassEntry(False)
        EnableDomainSelect(True)
        EnableProjectSelect(False)
        EnableTaskSelect(False)
        Exit Sub
Login_err:
        MsgBox("Login error: " & vbCrLf & Err.Description)
        DisplayStatusMessage("Ready")

    End Sub

    Private Sub SelectDomainCommand_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SelectDomainCommand.Click
        Dim proj As String
        Dim domainItem As String

        DisplayStatusMessage("Creating project List..")
        ProjectList.Items.Clear()
        If AllDomains Then
            ProjectList.Items.Clear()
            For Each domainItem In tdc.VisibleDomains
                For Each proj In tdc.VisibleProjects(domainItem)
                    ProjectList.Items.Add(domainItem + "." + proj)
                Next
            Next
        Else
            If DomainList.SelectedItems.Count < 1 Then
                MsgBox("Please select a domain!")
                Exit Sub
            End If
            For Each domainItem In DomainList.SelectedItems()
                For Each proj In tdc.VisibleProjects(domainItem)
                    ProjectList.Items.Add(domainItem & "." + proj)
                Next proj
            Next
        End If
        EnableUserPassEntry(False)
        EnableDomainSelect(False)
        EnableProjectSelect(True)
        EnableTaskSelect(False)
        DisplayStatusMessage("Please select project(s).")
    End Sub
    Private Sub SelectProjectCommand_Click(sender As Object, e As EventArgs) Handles SelectProjectCommand.Click

        If AllProjects Then
        Else
            If ProjectList.SelectedItems.Count < 1 Then
                MsgBox("Please select a project!")
                Exit Sub
            End If
        End If
        EnableUserPassEntry(False)
        EnableDomainSelect(False)
        EnableProjectSelect(False)
        EnableTaskSelect(True)
        DisplayStatusMessage("Ready.")
    End Sub
    Sub DisplayStatusMessage(ByRef msg As String)
        StatusMessageLabel.Text = msg
        StatusMessageLabel.Update()
        logMessage(msg)
    End Sub

    'This function checks if required folders exists and if not, will create the folder
    Public Sub FoldExists(ByRef Folder As String)
        On Error GoTo ErrorHandler
        Dim MyFileSystem As Object

        MyFileSystem = CreateObject("Scripting.FileSystemObject")

        If MyFileSystem.FolderExists(Folder) = False Then
            MyFileSystem.CreateFolder(Folder)
        End If
        MyFileSystem = Nothing

        GC.Collect()
        Exit Sub
ErrorHandler:
        MsgBox("Failed to access the log file directory.")
        MsgBox(Err.Description)
    End Sub



    Private Sub DomainList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DomainList.SelectedIndexChanged

    End Sub

    Private Sub RunCommand_Click(sender As Object, e As EventArgs) Handles RunCommand.Click
        Dim myproject As String
 
        SelectedProjectsList.Items.Clear()

        If AllProjects Then
            For Each myproject In ProjectList.Items
                SelectedProjectsList.Items.Add(myproject)
            Next
        Else 'Not all projects selected
            For Each myproject In ProjectList.SelectedItems()
                SelectedProjectsList.Items.Add(myproject)
            Next
        End If


        If TasksList.SelectedItem = "Rename Users" Then
            Me.Visible = False
            RenameUsers.Show()
        ElseIf TasksList.SelectedItem = "Add Users to Projects" Then
            Me.Visible = False
            AddUsersToProjects.Show()
        ElseIf TasksList.SelectedItem = "Move Users to Viewer Group" Then
            Me.Visible = False
            MoveUsersToViewer.Show()
        ElseIf TasksList.SelectedItem = "List Users" Then
            Me.Visible = False
            ListUsers.Show()
        End If

    End Sub


    Private Sub TasksList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TasksList.SelectedIndexChanged

    End Sub

   
End Class