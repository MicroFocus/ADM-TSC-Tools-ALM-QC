﻿Public Class AddUsersToProjects


    Private Sub AddUsersToProjects_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        AuthenticationForm.Visible = True
    End Sub

    Private Sub AddUsersToProjects_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim t As Integer
        LogText.Text = "The following projects were selected:"
        LogText.Update()

        For t = 0 To AuthenticationForm.SelectedProjectsList.Items.Count - 1
            LogText.Text = LogText.Text & vbCrLf & AuthenticationForm.SelectedProjectsList.Items.Item(t)
            LogText.Update()
        Next

    End Sub
    Sub StartTask()
        On Error GoTo ErrorHandler
        LogText.Text = "Starting task..."
        LogText.Update()

        ReadExcel()
        LogText.Text = LogText.Text & vbCrLf & "Reading project(s) selection."
        LogText.Update()

        Dim t As Integer
        Dim myproject As Object
        For t = 0 To AuthenticationForm.SelectedProjectsList.Items.Count - 1
            If AuthenticationForm.tdc.ProjectConnected Then
                AuthenticationForm.tdc.Disconnect()
            End If
            On Error Resume Next
            myproject = Split(AuthenticationForm.SelectedProjectsList.Items.Item(t), ".")
            AuthenticationForm.tdc.Connect(myproject(0), myproject(1))
            If Err.Number <> 0 Then
                LogText.Text = LogText.Text & vbCrLf & "Err: Failed to connect to project " & "[" & myproject(0) & ":" & myproject(1) & "]."
                LogText.Update()
                Exit Sub
            Else
                LogText.Text = LogText.Text & vbCrLf & "Connected to project " & "[" & myproject(0) & ":" & myproject(1) & "]."
                LogText.Update()
                RunTask()
            End If

        Next

        If AuthenticationForm.tdc.Connected Then
            AuthenticationForm.tdc.Disconnect()
        End If
        LogText.Text = LogText.Text & vbCrLf & "Done!"
        Exit Sub

ErrorHandler:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub

    Sub RunTask()
        On Error GoTo ErrorHandler

        Dim SecondColumn() 'As Object
        Dim countmembership As Integer
        Dim usercount As Integer
        Dim username As String
        Dim groupName As String
        Dim GroupExist As Boolean
        Dim currCustuser As Object 'As CustomizationUser
        Dim userexist As Boolean
        Dim cust As Object 'As Customization
        Dim custusers As Object 'As CustomizationUsers
        Dim custuser As Object 'As CustomizationUser
        Dim custGroups As Object 'As CustomizationUsersGroups
        Dim custGroup As Object 'As CustomizationUsersGroup
        Dim userslist As Object 'As TDAPIOLELib.List
        Dim usercountitem As Integer
        Dim userId As Integer
        Dim fullname As String
        Dim email As String
        Dim description As String
        Dim phone As String

        userexist = False
        GroupExist = False


        If UsersGroup_list.Items.Count = 0 Then
            LogText.Text = LogText.Text & vbCrLf & "Users list is empty. No user will be added to project."
            LogText.Update()

            Exit Sub
        End If
        LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]  Preparing to add [USER] to [GROUP]."
        LogText.Update()




        'Load customization object
        cust = AuthenticationForm.tdc.Customization
        cust.Load()
        custGroups = cust.UsersGroups
        custusers = cust.Users
        countmembership = 0


        For usercount = 0 To UsersGroup_list.Items.Count - 1
            SecondColumn = Split(UsersGroup_list.Items.Item(usercount), "|")


            username = Trim(SecondColumn(0))
            groupName = Trim(SecondColumn(1))

            userexist = False
            GroupExist = False

            'Check to see if user exist in Site Admin
            If custusers.UserExistsInSite(username) Then
                'continue to add to project

                'Check to see if user exist in project
                userslist = custusers.Users
                For usercountitem = 1 To userslist.count
                    currCustuser = userslist.Item(usercountitem)
                    If LCase(currCustuser.Name) = LCase(username) Then
                        userexist = True
                    End If
                Next


                'Check to see if the group exist before adding
                For Each custGroup In custGroups.Groups
                    'find the group that you want to add the user to
                    If LCase(groupName) = LCase(custGroup.Name) Then

                        GroupExist = True
                        'Add user to project if he deos not exist
                        If userexist = False Then

                            LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Adding user [" & username & "] to project."""
                            LogText.Update()

                            On Error Resume Next
                            Err.Clear()
                            'Add user to project
                            custuser = custusers.AddUser(username)
                 
                            If Err.Number <> 0 Then
                                LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & Err.Description & "."
                                LogText.Update()
                            Else
                                LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]" & " User [" & username & "] was added successfully."
                                LogText.Update()
                                Err.Clear()

                                'Add user to group
                                custuser.AddToGroup(groupName)
                                If Err.Number <> 0 Then
                                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & Err.Description & "."
                                    LogText.Update()
                                Else
                                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]" & " User [" & username &
                                    "] was added to group [" & groupName & "] successfully."
                                    LogText.Update()
                                End If

                            End If



                        Else
                            'user already exist in project
                            currCustuser = custusers.user(username)
                            'If user already exist in group
                            If currCustuser.InGroup(groupName) Then
                                LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] User [" & username & "] already exist in group [" & groupName & "]."
                                LogText.Update()
                            Else
                                'User does not exist in group so add user to group
                                On Error Resume Next
                                Err.Clear()
                                currCustuser.AddToGroup(groupName)

                                If Err.Number <> 0 Then
                                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & Err.Description & "."
                                    LogText.Update()
                                Else
                                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]" & " User [" & username &
                                    "] was added to group [" & groupName & "] successfully."
                                    LogText.Update()
                                End If

                            End If 'end user already in group
                        End If 'end check user in project
                    End If  'end group check

                Next 'loop through each group

                If GroupExist = False Then
                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]" & " Err: Group [" & groupName & "] does not exist."
                    LogText.Update()
                End If

            Else

                LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] User " & username & " does not exist in Site Admin. Please add user to instance first."
                LogText.Update()
            End If
        Next

        cust.Commit()
        cust = Nothing
        custusers = Nothing
        custuser = Nothing
        currCustuser = Nothing
        Exit Sub

ErrorHandler:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub



    Private Sub Start_Click(sender As Object, e As EventArgs) Handles Start.Click
        StartTask()
        logMessage(LogText.Text)
    End Sub

    'Read the excel sheet and insert it into the users_list object.
    Private Sub ReadExcel()
        On Error GoTo Exp
        LogText.Text = LogText.Text & vbCrLf & "Reading Excel file."
        LogText.Update()

        Dim Row As Integer
        Dim FirstColumn As String
        Dim myExcel As Object

        Dim username As String
        Dim fullname As String
        Dim email As String
        Dim description As String
        Dim phone As String
        Dim groupname As String
        Dim data As String

        myExcel = CreateObject("Excel.Application")

        'Close Excel file
        myExcel.Workbooks.Close()

        'Open Excel file for reading
        myExcel.Workbooks.Open(TextBox1.Text, , True)

        'Bring up Excel app
        'myExcel.Visible = True

        'Select the worksheet
        myExcel.Worksheets("Sheet1").Activate()

        'reset list

        UsersGroup_list.Items.Clear()

        '////Reading excel file
        Row = 1

        Do
            Row = Row + 1
            data = ""

            username = Trim(myExcel.activesheet.cells(Row, 1).Value)
            groupname = Trim(myExcel.activesheet.cells(Row, 2).Value)
            If username = "" Then
                LogText.Text = LogText.Text & vbCrLf & "Finished reading Excel file."
                LogText.Update()

            Else


                data = username & "|" & groupname


                UsersGroup_list.Items.Add(data)


            End If

        Loop While Not data = ""

        'Close Excel file
        myExcel.Workbooks.Close()

        myExcel = Nothing
        Exit Sub
Exp:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class