﻿Public Class ListUsers
    Dim Excel
    Dim Sheet
    Dim Row As Long
    Private Sub ListUsers_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        AuthenticationForm.Visible = True
    End Sub

    Private Sub ListUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim t As Integer
        LogText.Text = "The following projects were selected:"
        LogText.Update()

        For t = 0 To AuthenticationForm.SelectedProjectsList.Items.Count - 1
            LogText.Text = LogText.Text & vbCrLf & AuthenticationForm.SelectedProjectsList.Items.Item(t)
            LogText.Update()
        Next

    End Sub
    Sub StartTask()
        On Error GoTo ErrorHandler
        LogText.Text = "Starting task..."
        LogText.Update()

        LogText.Text = LogText.Text & vbCrLf & "Reading project(s) selection."
        LogText.Update()

        Dim t As Integer
        Dim myproject As Object
        SetupExcel()
        Row = 2
        For t = 0 To AuthenticationForm.SelectedProjectsList.Items.Count - 1
            If AuthenticationForm.tdc.ProjectConnected Then
                AuthenticationForm.tdc.Disconnect()
            End If
            On Error Resume Next
            myproject = Split(AuthenticationForm.SelectedProjectsList.Items.Item(t), ".")
            AuthenticationForm.tdc.Connect(myproject(0), myproject(1))
            If Err.Number <> 0 Then
                LogText.Text = LogText.Text & vbCrLf & "Err: Failed to connect to project " & "[" & myproject(0) & ":" & myproject(1) & "]."
                LogText.Update()
                Exit Sub
            Else
                LogText.Text = LogText.Text & vbCrLf & "Connected to project " & "[" & myproject(0) & ":" & myproject(1) & "]."
                LogText.Update()
                Call GetPermission()
            End If

        Next

        If AuthenticationForm.tdc.Connected Then
            AuthenticationForm.tdc.Disconnect()
        End If

        'Save the newly created workbook and close Excel.
        Excel.ActiveWorkbook.SaveAs(TextBox1.Text)
        Excel.Quit

        LogText.Text = LogText.Text & vbCrLf & "Done!"


        Exit Sub

ErrorHandler:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub
    Sub SetupExcel()

        Excel = CreateObject("Excel.Application") 'Open Excel
        Excel.WorkBooks.Add() 'Add a new workbook

        'Get the first worksheet.
        Sheet = Excel.ActiveSheet

        'sheet name as Group Permission
        Sheet.Name = "Group Permission"

        'Specify the Excel Sheet Properties  
        With Sheet.Range("A1:H1")
            .Font.Name = "Arial"
            .Font.FontStyle = "Bold"
            .Font.Size = 10
            .Font.Bold = True
            .Interior.ColorIndex = 15 'Light Grey
        End With

        'Excel Sheet Column Header Values
        Sheet.Cells(1, 1) = "User ID"
        Sheet.Cells(1, 2) = "Full Name"
        Sheet.Cells(1, 3) = "Email"
        Sheet.Cells(1, 4) = "Phone"
        Sheet.Cells(1, 5) = "Domain"
        Sheet.Cells(1, 6) = "Project"
        Sheet.Cells(1, 7) = "Role(s)"
    End Sub

    '////////////////////////////////////////////////////////////////////////////////////
    '//
    '// ---'Get Group Permission--
    '///////////////////////////////////////////////////////////////////////////////////
    Sub GetPermission()
        On Error Resume Next

        'ALM 
        Dim cust
        Dim custus
        Dim custu
        Dim myuser
        Dim groupname
        Dim custgroups
        Dim groupid
        Dim groupList


        Err.Clear()
        cust = AuthenticationForm.tdc.Customization
        If Err.Number <> 0 Then
            Exit Sub
        End If

        cust.Load
        custus = cust.Users
        custgroups = cust.UsersGroups


        For Each custu In custus.Users
            groupList = ""
            For Each groupname In custgroups.Groups
                'Determine which groups the user is in
                If custu.InGroup(groupname.Name) Then
                    If groupList = "" Then
                        groupList = groupname.Name
                    Else
                        groupList = groupname.Name & ";" & groupList
                    End If
                End If
            Next

            Sheet.Cells(Row, 1).Value = custu.Name
            Sheet.Cells(Row, 2).Value = custu.FullName
            Sheet.Cells(Row, 3).Value = custu.Email
            Sheet.Cells(Row, 4).Value = custu.Phone
            Sheet.Cells(Row, 5).Value = AuthenticationForm.tdc.domainname
            Sheet.Cells(Row, 6).Value = AuthenticationForm.tdc.projectname
            Sheet.Cells(Row, 7).Value = groupList
            Row = Row + 1
        Next

        cust = Nothing
        custus = Nothing
        custu = Nothing
        custgroups = Nothing

    End Sub
    Private Sub Start_Click(sender As Object, e As EventArgs) Handles Start.Click

        StartTask()
        logMessage(LogText.Text)
    End Sub


End Class