﻿Public Class RenameUsers
    Dim RenameUser_list As New ListBox

    Private Sub RenameUsers_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        AuthenticationForm.Visible = True
    End Sub


    Sub StartTask()
        On Error Resume Next
        LogText.Text = "Starting task..."
        LogText.Update()

        ReadExcel()
        LogText.Text = LogText.Text & vbCrLf & "Reading project(s) selection."
        LogText.Update()

        Dim t As Integer
        Dim myproject As Object
        For t = 0 To AuthenticationForm.SelectedProjectsList.Items.Count - 1
            If AuthenticationForm.tdc.ProjectConnected Then
                AuthenticationForm.tdc.Disconnect()
            End If
            myproject = Split(AuthenticationForm.SelectedProjectsList.Items.Item(t), ".")
            AuthenticationForm.tdc.Connect(myproject(0), myproject(1))
            If Err.Number <> 0 Then
                LogText.Text = LogText.Text & vbCrLf & "Err: Failed to connect to project " & "[" & myproject(0) & ":" & myproject(1) & "]."
                LogText.Update()
                Exit Sub
            Else
                LogText.Text = LogText.Text & vbCrLf & "Connected to project " & "[" & myproject(0) & ":" & myproject(1) & "]."
                LogText.Update()
                RenameUser()
            End If

        Next

        If AuthenticationForm.tdc.Connected Then
            AuthenticationForm.tdc.Disconnect()
        End If
        LogText.Text = LogText.Text & vbCrLf & "Done!"

        Exit Sub

ErrorHandler:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub

    Private Sub Start_Click(sender As Object, e As EventArgs) Handles Start.Click

        StartTask()
        ' logMessage(LogText.Text)
    End Sub

    Private Sub ReadExcel()
        On Error GoTo Exp

        LogText.Text = LogText.Text & vbCrLf & "Reading Excel file."
        Dim Row As Integer
        Dim FirstColumn As String
        Dim SecondColumn As String

        Dim myExcel

        myExcel = CreateObject("Excel.Application")

        'Close Excel file
        myExcel.Workbooks.Close

        'Open Excel file for reading
        myExcel.Workbooks.Open(TextBox1.Text, , True)

        'Bring up Excel app
        myExcel.Visible = False

        'Select the worksheet
        myExcel.Worksheets("Sheet1").Activate

        'reset list
        RenameUser_list.Items.Clear()

        '////Reading excel file
        Row = 1
        Do
            Row = Row + 1
            FirstColumn = myExcel.activesheet.cells(Row, 1).Value
            SecondColumn = myExcel.activesheet.cells(Row, 2).Value
            If FirstColumn = "" Or IsNothing(FirstColumn) Then
                LogText.Text = LogText.Text & vbCrLf & "Last Excel row reached. Stop reading excel file."
            Else
                If SecondColumn <> "" Then
                    RenameUser_list.Items.Add(FirstColumn & ":" & SecondColumn) 'Trim(myExcel.activesheet.cells(Row, 2).Value)
                End If
            End If

        Loop While Not FirstColumn = ""

        myExcel.Workbooks.Close()
        myExcel = Nothing
        Exit Sub
Exp:

        LogText.Text = LogText.Text & vbCrLf & Err.Description
    End Sub
    Sub RenameUser()
        'Code from Bilal
        On Error GoTo Exp

        Dim UserData() As String
        Dim txtUserName As String
        Dim txtNewName As String
        Dim UserIndex As Integer
        Dim glist 'As TDAPIOLELib.List
        Dim CustUsersGroups 'As CustomizationUsersGroups
        Dim CustGroup 'As CustomizationUsersGroup
        Dim CustUsers ' As CustomizationUsers
        Dim CustUser 'As CustomizationUser
        Dim CustUserNew 'As CustomizationUser
        Dim selCmdB 'As TDAPIOLELib.Command
        Dim selCmd 'As TDAPIOLELib.Command
        Dim rst 'as TDAPIOLELib.Recordset
        Dim rstB 'As TDAPIOLELib.Recordset
        Dim Grp 'As CustomizationUsersGroup
        Dim rcset 'As TDAPIOLELib.Recordset
        Dim updateCmd 'As TDAPIOLELib.Command
        Dim cmd 'As TDAPIOLELib.Command
        Dim msg As String
        Dim count As Integer
        Dim selSQL As String
        Dim selSQLB As String
        Dim userDoesntExist As String
        Dim naffectedRows As Integer
        Dim tableName As String
        Dim colName As String
        Dim updateSQL As String
        Dim i As Integer



        logMessage("Renaming " & RenameUser_list.Items.Count & " users.")
        For UserIndex = 0 To RenameUser_list.Items.Count - 1
            UserData = Split(RenameUser_list.Items.Item(UserIndex), ":")
            txtUserName = Trim(LCase(UserData(0)))
            txtNewName = Trim(LCase(UserData(1)))


            LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Renaming " & txtUserName & " to " & txtNewName & " (" & UserIndex + 1 & " of " & RenameUser_list.Items.Count & ")."


            ' -\-\-\-\- Verify that the old user exists in project -\-\-\-\-
            selCmd = AuthenticationForm.tdc.Command

            selSQL = "SELECT COUNT(*) FROM USERS WHERE LOWER(US_USERNAME)='" & txtUserName & "'"
            selSQLB = "SELECT COUNT(*) FROM USERS WHERE LOWER(US_USERNAME)='" & txtNewName & "'"

            selCmd.CommandText = selSQL
            rst = selCmd.Execute
            userDoesntExist = rst.FieldValue(0)
            'Check if old user exist in project
            If (userDoesntExist = "0") Then
                LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: Old username (" & txtUserName & ") does not exist in project."
                LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: Failed to replace user " & txtUserName & " with " & txtNewName

            Else
                ' -\-\-\-\- Verify that the new user does not exist in project -\-\-\-\-
                selCmdB = AuthenticationForm.tdc.Command
                selCmdB.CommandText = selSQLB
                rstB = selCmdB.Execute
                userDoesntExist = rstB.FieldValue(0)
                'check if new exist in project
                If (userDoesntExist <> "0") Then
                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: New username (" & txtNewName & ") already exists in project."
                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: Failed to replace user " & txtUserName & " with " & txtNewName
                    Exit For
                Else
                    On Error Resume Next
                    ' *************** Get user group(s) ***************
                    'Get customization data into the local cache
                    'AuthenticationForm.tdc.Customization.Load

                    'Get the groups that the old user belong to
                    CustUsers = AuthenticationForm.tdc.Customization.Users
                    CustUser = CustUsers.User(txtUserName)
                    glist = CustUser.GroupsList

                    ' *************** Add new user to the same group as the old user **************
                    'Check to see if the new user exist
                    If Not AuthenticationForm.tdc.Customization.Users.UserExistsInSite(txtNewName) Then
                        LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] User " & txtNewName & " does not exist in Site Admin." & Err.Description
                        LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: Failed to replace user " & txtUserName & " with " & txtNewName
                        Exit For
                    End If

                    'Add user to the project with the CustomizationUsers Object
                    ' referenced through TDConnection.Customization.Users
                    CustUserNew = AuthenticationForm.tdc.Customization.Users.AddUser(txtNewName)
                    If Err.Number <> 0 Then
                        LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: User " & txtNewName & " already exist in project." & Err.Description
                        LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: Failed to replace user " & txtUserName & " with " & txtNewName
                        Exit For
                    End If

                    If Err.Number <> 0 Then
                        LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: Failed to commit update." & Err.Description
                        LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Error: Failed to replace user " & txtUserName & " with " & txtNewName
                        Exit For
                    End If

                    'addToUserGroup is a group name, for example "QATester"

                    For Each Grp In glist
                        'Add the user
                        'Grp.AddUser CStr(txtNewName)
                        Err.Clear()
                        CustUserNew.AddToGroup(Grp.Name)

                        ' If Err.Number <> 0 Then
                        'logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Failed to added " & txtNewName & " to group " & Grp.Name & "." & Err.Description)
                        'End If
                        'Commit the changes to the project
                    Next Grp
                    AuthenticationForm.tdc.Customization.Commit

                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Updating project data to replace " & txtUserName & " with " & txtNewName & "."


                    ' ************************** Update PROJECT DB *********************
                    ' -\-\-\- Updating users table. -\-\-\-\-

                    updateCmd = AuthenticationForm.tdc.Command

                    naffectedRows = -1

                    ' -/-/-/- Updating project tables in which the user name is written (UserCombo) -/-/-/-/-
                    cmd = AuthenticationForm.tdc.Command
                    cmd.CommandText = "select SF_TABLE_NAME, SF_COLUMN_NAME FROM SYSTEM_FIELD WHERE SF_EDIT_STYLE='UserCombo'"
                    rcset = cmd.Execute

                    ' ************************** Updating Regular tables *********************
                    On Error Resume Next
                    While (rcset.EOR = False)
                        naffectedRows = -1
                        tableName = rcset.FieldValue(0)
                        colName = rcset.FieldValue(1)
                        updateSQL = "UPDATE " + tableName + " set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                        updateCmd.CommandText = updateSQL
                        updateCmd.Execute
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg

                        If tableName = "ASSET_RELATIONS" Then

                            updateSQL = "UPDATE HIST_ASSET_RELATIONS set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_ASSET_RELATIONS :" & Err.Description)
                            Else
                                'naffectedRows = updateCmd.AffectedRows
                                'msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_ASSET_RELATIONS  set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_ASSET_RELATIONS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "ASSET_REPOSITORY_ITEMS" Then

                            updateSQL = "UPDATE HIST_ASSET_REPOSITORY_ITEMS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_ASSET_REPOSITORY_ITEMS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            updateSQL = "UPDATE VC_ASSET_REPOSITORY_ITEMS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_ASSET_REPOSITORY_ITEMS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "BP_ITER_PARAM" Then

                            updateSQL = "UPDATE HIST_BP_ITER_PARAM    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_BP_ITER_PARAM :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_BP_ITER_PARAM   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_BP_ITER_PARAM :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "BP_ITERATION" Then

                            updateSQL = "UPDATE HIST_BP_ITERATION    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_BP_ITERATION :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_BP_ITERATION   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_BP_ITERATION :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "BP_PARAM" Then

                            updateSQL = "UPDATE HIST_BP_PARAM    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_BP_PARAM :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_BP_PARAM   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_BP_PARAM :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "BPM_ELEMENTS" Then

                            updateSQL = "UPDATE HIST_BPM_ELEMENTS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_BPM_ELEMENTS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_BPM_ELEMENTS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_BPM_ELEMENTS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "BPM_MODELS" Then

                            updateSQL = "UPDATE HIST_BPM_MODELS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_BPM_MODELS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_BPM_MODELS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_BPM_MODELS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If


                        If tableName = "BPM_PATHS" Then

                            updateSQL = "UPDATE HIST_BPM_PATHS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_BPM_PATHS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_BPM_PATHS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_BPM_PATHS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "BPTEST_TO_COMPONENTS" Then

                            updateSQL = "UPDATE HIST_BPTEST_TO_COMPONENTS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_BPTEST_TO_COMPONENTS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_BPTEST_TO_COMPONENTS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_BPTEST_TO_COMPONENTS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "COMPONENT" Then

                            updateSQL = "UPDATE HIST_COMPONENT    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_COMPONENT :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_COMPONENT    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_COMPONENT :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "COMPONENT_STEP" Then

                            updateSQL = "UPDATE HIST_COMPONENT_STEP   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_COMPONENT_STEP :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_COMPONENT_STEP    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_COMPONENT_STEP :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "COMPONENT_STEP_PARAMS" Then

                            updateSQL = "UPDATE HIST_COMPONENT_STEP_PARAMS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_COMPONENT_STEP_PARAMS :" & Err.Description
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_COMPONENT_STEP_PARAMS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_COMPONENT_STEP_PARAMS :" & Err.Description
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "CROS_REF" Then

                            updateSQL = "UPDATE HIST_CROS_REF    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_CROS_REF :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_CROS_REF   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_CROS_REF :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "DESSTEPS" Then

                            updateSQL = "UPDATE HIST_DESSTEPS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_DESSTEPS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_DESSTEPS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_DESSTEPS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "FACETS" Then

                            updateSQL = "UPDATE HIST_FACETS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_FACETS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_FACETS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_FACETS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "FRAMEWORK_PARAM" Then

                            updateSQL = "UPDATE HIST_FRAMEWORK_PARAM    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_FRAMEWORK_PARAM :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_FRAMEWORK_PARAM    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_FRAMEWORK_PARAM :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If
                        If tableName = "REQ" Then

                            updateSQL = "UPDATE HIST_REQ    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_REQ :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_REQ   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_REQ :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If


                        If tableName = "RESOURCES" Then

                            updateSQL = "UPDATE HIST_RESOURCES    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_RESOURCES :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_RESOURCES    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_RESOURCES :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "RUNTIME_PARAM" Then

                            updateSQL = "UPDATE HIST_RUNTIME_PARAM    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_RUNTIME_PARAM :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_RUNTIME_PARAM    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_RUNTIME_PARAM :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "STEP_PARAMS" Then

                            updateSQL = "UPDATE HIST_STEP_PARAMS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_STEP_PARAMS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_STEP_PARAMS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_STEP_PARAMS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "TEST" Then

                            updateSQL = "UPDATE HIST_TEST   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_TEST :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_TEST    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_TEST :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "TEST_CONFIGS" Then

                            updateSQL = "UPDATE HIST_TEST_CONFIGS   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_TEST_CONFIGS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_TEST_CONFIGS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_TEST_CONFIGS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "TEST_CRITERIA" Then

                            updateSQL = "UPDATE HIST_TEST_CRITERIA   set  " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_TEST_CRITERIA :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_TEST_CRITERIA    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_TEST_CRITERIA :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "TEST_PARAMS" Then

                            updateSQL = "UPDATE HIST_TEST_PARAMS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_TEST_PARAMS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                '  logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_TEST_PARAMS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_TEST_PARAMS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If

                        If tableName = "USER_ASSETS" Then

                            updateSQL = "UPDATE HIST_USER_ASSETS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] HIST_USER_ASSETS :" & Err.Description)
                            Else
                                naffectedRows = updateCmd.AffectedRows
                                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If

                            updateSQL = "UPDATE VC_USER_ASSETS    set " + colName + " = '" + txtNewName + "' WHERE lower(" + colName + ") = '" + txtUserName + "'"
                            updateCmd.CommandText = updateSQL
                            Err.Clear()
                            updateCmd.Execute
                            If Err.Number <> 0 Then
                                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_USER_ASSETS :" & Err.Description)
                            Else
                                'naffectedRows = updateCmd.AffectedRows
                                'msg = updateSQL & " - Affected " & naffectedRows & " lines."
                                'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                            End If
                        End If
                        rcset.Next
                    End While



                    'VC_COMPONENT_MULTIVALUE
                    updateSQL = "UPDATE VC_COMPONENT_MULTIVALUE    set COMV_USER_NAME = '" + txtNewName + "' WHERE lower(COMV_USER_NAME) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_COMPONENT_MULTIVALUE :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If

                    'VC_REQ_MULTIVALUE
                    updateSQL = "UPDATE VC_REQ_MULTIVALUE    set RQMV_USER_NAME = '" + txtNewName + "' WHERE lower(RQMV_USER_NAME) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_REQ_MULTIVALUE :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If

                    'VC_RESOURCES_MULTIVALUE
                    updateSQL = "UPDATE VC_RESOURCES_MULTIVALUE   set  RSCMV_USER_NAME = '" + txtNewName + "' WHERE lower(RSCMV_USER_NAME) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_RESOURCES_MULTIVALUE :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If


                    'VC_TEST_MULTIVALUE
                    updateSQL = "UPDATE VC_TEST_MULTIVALUE   set  TSMV_USER_NAME = '" + txtNewName + "' WHERE lower(TSMV_USER_NAME ) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_TEST_MULTIVALUE :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        'logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If


                    'VC_DELETED_ASSETS_INFO
                    'updateSQL = "UPDATE VC_DELETED_ASSETS_INFO  DAI_DELETED_BY = '" + txtNewName + "' WHERE lower(DAI_DELETED_BY) = '" + txtUserName + "'"
                    'updateCmd.CommandText = updateSQL
                    'Err.Clear
                    'updateCmd.Execute
                    'If Err.Number <> 0 Then
                    '    logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] VC_DELETED_ASSETS_INFO :" & Err.Description
                    'Else
                    '    naffectedRows = updateCmd.AffectedRows
                    '    msg = updateSQL & " - Affected " & naffectedRows & " lines."
                    '   ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    'End If

                    'DELETED_ASSETS_INFO
                    'updateSQL = "UPDATE DELETED_ASSETS_INFO  DAI_DELETED_BY = '" + txtNewName + "' WHERE lower(DAI_DELETED_BY) = '" + txtUserName + "'"
                    'updateCmd.CommandText = updateSQL
                    'Err.Clear
                    'updateCmd.Execute
                    'If Err.Number <> 0 Then
                    '    logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] DELETED_ASSETS_INFO :" & Err.Description
                    'Else
                    '    naffectedRows = updateCmd.AffectedRows
                    '    msg = updateSQL & " - Affected " & naffectedRows & " lines."
                    '   ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    'End If

                    ' ************************** Updating Common_Settings table *********************
                    updateSQL = "UPDATE COMMON_SETTINGS   set  CSET_OWNER = '" + txtNewName + "' WHERE lower(CSET_OWNER) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] COMMON_SETTINGS :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If


                    ' ************************** Updating Favorites table *********************
                    updateSQL = "UPDATE FAVORITES    set FAV_OWNER = '" + txtNewName + "' WHERE lower(FAV_OWNER) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] FAVORITES :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If

                    updateSQL = "UPDATE FAVORITE_FOLDERS   set  FF_OWNER = '" + txtNewName + "' WHERE lower(FF_OWNER) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] FAVORITE_FOLDERS :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If

                    ' ************************** Updating Analysis tables *********************
                    updateSQL = "UPDATE ANALYSIS_ITEM_FOLDERS   set  AIF_OWNER = '" + txtNewName + "' WHERE lower(AIF_OWNER) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] ANALYSIS_ITEM_FOLDERS :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If

                    updateSQL = "UPDATE ANALYSIS_ITEMS   set  AI_OWNER = '" + txtNewName + "' WHERE lower(AI_OWNER) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] ANALYSIS_ITEMS :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If

                    updateSQL = "UPDATE ANALYSIS_ITEMS   set  AI_MODIFIED_BY = '" + txtNewName + "' WHERE lower(AI_MODIFIED_BY) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] ANALYSIS_ITEMS :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If

                    ' ************************** Updating Dashboard tables *********************
                    updateSQL = "UPDATE DASHBOARD_FOLDERS    set DF_OWNER = '" + txtNewName + "' WHERE lower(DF_OWNER) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] DASHBOARD_FOLDERS :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If



                    updateSQL = "UPDATE DASHBOARD_PAGES   set  DP_OWNER = '" + txtNewName + "' WHERE lower(DP_OWNER) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] DASHBOARD_PAGES :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If


                    updateSQL = "UPDATE DASHBOARD_PAGES    set DP_MODIFIED_BY = '" + txtNewName + "' WHERE lower(DP_MODIFIED_BY) = '" + txtUserName + "'"
                    updateCmd.CommandText = updateSQL
                    Err.Clear()
                    updateCmd.Execute
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] DASHBOARD_PAGES :" & Err.Description)
                    Else
                        naffectedRows = updateCmd.AffectedRows
                        msg = updateSQL & " - Affected " & naffectedRows & " lines."
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    End If
                    '            ' ************************** Updating Audti Log table *********************
                    '            updateSQL = "UPDATE AUDIT_LOG  AU_USER = '" + txtNewName + "' WHERE lower(AU_USER) = '" + txtUserName + "'"
                    '            updateCmd.CommandText = updateSQL
                    '            Err.Clear
                    '            updateCmd.Execute
                    '            If Err.Number <> 0 Then
                    '                logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] AUDIT_LOG :" & Err.Description
                    '            Else
                    '                naffectedRows = updateCmd.AffectedRows
                    '                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                    '                logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    '            End If

                    '            ' ************************** Updating Audti Properties table *********************
                    '            updateSQL = "UPDATE AUDIT_PROPERTIES  AP_OLD_VALUE = '" + txtNewName + "' WHERE lower(AP_OLD_VALUE) = '" + txtUserName + "'"
                    '            updateCmd.CommandText = updateSQL
                    '            Err.Clear
                    '            updateCmd.Execute
                    '            If Err.Number <> 0 Then
                    '                logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] AUDIT_PROPERTIES :" & Err.Description
                    '            Else
                    '                naffectedRows = updateCmd.AffectedRows
                    '                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                    '                logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    '            End If

                    '            updateSQL = "UPDATE AUDIT_PROPERTIES   AP_NEW_VALUE = '" + txtNewName + "' WHERE lower( AP_NEW_VALUE) = '" + txtUserName + "'"
                    '            updateCmd.CommandText = updateSQL
                    '            Err.Clear
                    '            updateCmd.Execute
                    '            If Err.Number <> 0 Then
                    '                logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] AUDIT_PROPERTIES :" & Err.Description
                    '            Else
                    '                naffectedRows = updateCmd.AffectedRows
                    '                msg = updateSQL & " - Affected " & naffectedRows & " lines."
                    '                logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] " & msg
                    '            End If
                    Err.Clear()
                    'remove old user
                    AuthenticationForm.tdc.Customization.Users.RemoveUser(txtUserName)
                    If Err.Number <> 0 Then
                        logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]Error: Failed to commit update." & Err.Description)
                    Else
                        ' logmessage( "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Removed " & txtUserName & " from project." & Err.Description
                    End If

                'Commit the changes to the project
                AuthenticationForm.tdc.Customization.Commit
                If Err.Number <> 0 Then
                    logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]Error: Failed to commit update." & Err.Description)
                    Exit For
                End If

                logMessage("[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Completed update to replace user " & txtUserName & " with " & txtNewName)

            End If

            End If 'end of check if user exist

        Next ' end of reading users list to rename

        rst = Nothing
        selCmd = Nothing
        selCmdB = Nothing
        rstB = Nothing
        CustUsers = Nothing
        CustUser = Nothing
        glist = Nothing
        CustUsersGroups = Nothing
        CustGroup = Nothing
        updateCmd = Nothing
        rcset = Nothing
        cmd = Nothing

        Exit Sub
Exp:
    End Sub
    Private Sub RenameUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class