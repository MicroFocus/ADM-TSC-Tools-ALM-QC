﻿Public Class MoveUsersToViewer

    Dim projectusers As New ListBox
    Dim ReadOnlyGroup As String

    Private Sub MoveUsersToViewer_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        AuthenticationForm.Visible = True

    End Sub

    Private Sub MoveUsersToViewer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim t As Integer
        LogText.Text = "The following projects were selected:"
        LogText.Update()

        For t = 0 To AuthenticationForm.SelectedProjectsList.Items.Count - 1
            LogText.Text = LogText.Text & vbCrLf & AuthenticationForm.SelectedProjectsList.Items.Item(t)
            LogText.Update()
        Next

    End Sub
    Sub StartTask()
        On Error Resume Next
        LogText.Text = "Starting task..."
        LogText.Update()


        LogText.Text = LogText.Text & vbCrLf & "Reading project(s) selection."
        LogText.Update()

        Dim t As Integer
        Dim myproject As Object
        For t = 0 To AuthenticationForm.SelectedProjectsList.Items.Count - 1
            If AuthenticationForm.tdc.ProjectConnected Then
                AuthenticationForm.tdc.Disconnect()
            End If
            myproject = Split(AuthenticationForm.SelectedProjectsList.Items.Item(t), ".")
            AuthenticationForm.tdc.Connect(myproject(0), myproject(1))
            If Err.Number <> 0 Then
                LogText.Text = LogText.Text & vbCrLf & "Err: Failed to connect to project " & "[" & myproject(0) & ":" & myproject(1) & "]."
                LogText.Update()
                Exit Sub
            Else
                LogText.Text = LogText.Text & vbCrLf & "Connected to project " & "[" & myproject(0) & ":" & myproject(1) & "]."
                LogText.Update()
                ReadOnlyGroup = ""
                RunTask()
            End If

        Next

        If AuthenticationForm.tdc.Connected Then
            AuthenticationForm.tdc.Disconnect()
        End If
        LogText.Text = LogText.Text & vbCrLf & "Done!"
        Exit Sub

ErrorHandler:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub

    Sub RunTask()
        ReadExcel()
        If ReadOnlyGroup <> "" Then
            GetProjectUsers()
            AddUsersViewerGroup()
            RemoveUserFromProjectGroup()
        Else
            LogText.Text = LogText.Text & vbCrLf & "Readonly only group has not been specified."
            LogText.Update()
        End If

    End Sub



    Private Sub Start_Click(sender As Object, e As EventArgs) Handles Start.Click
        projectusers.Items.Clear()
        StartTask()
        logMessage(LogText.Text)
    End Sub

    'Read the excel sheet and insert it into the users_list object.
    Private Sub ReadExcel()
        On Error GoTo Exp
        LogText.Text = LogText.Text & vbCrLf & "Reading Excel file."
        LogText.Update()

        Dim Row As Integer
        Dim FirstColumn As String
        Dim myExcel As Object

        myExcel = CreateObject("Excel.Application")

        'Close Excel file
        myExcel.Workbooks.Close()

        'Open Excel file for reading
        myExcel.Workbooks.Open(TextBox1.Text, , True)

        'Bring up Excel app
        'myExcel.Visible = True

        'Select the worksheet
        myExcel.Worksheets("Sheet1").Activate()

        'reset list


        '////Reading excel file
        Row = 1

        FirstColumn = LCase(Trim(myExcel.activesheet.cells(Row, 1).Value))
        If FirstColumn = "readonly" Then
            If myExcel.activesheet.cells(Row, 2).Value <> "" Then
                ReadOnlyGroup = myExcel.activesheet.cells(Row, 2).Value
            End If
        End If


            'Close Excel file
            myExcel.Workbooks.Close()

        myExcel = Nothing
        Exit Sub
Exp:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub
    Private Sub GetProjectUsers()
        Dim cust As Object 'As Customization
        Dim custusers As Object 'As CustomizationUsers
        Dim custuser As Object 'As CustomizationUser
        Dim UsersList As Object 'list

        UsersToMove_list.Items.Clear()
        cust = AuthenticationForm.tdc.Customization
        cust.Load()
        custusers = cust.Users
        UsersList = custusers.Users
        For Each custuser In UsersList

            UsersToMove_list.Items.Add(LCase(custuser.name))
        Next
        cust = Nothing
        custusers = Nothing

    End Sub
    Private Sub AddUsersViewerGroup()
        On Error Resume Next
        Dim cust As Object 'As Customization
        Dim custusers As Object 'As CustomizationUsers
        Dim custuser As Object 'As CustomizationUser
        Dim UsersList As Object 'list

        Dim usercount As Integer
        Dim username As String
        Dim usercountitem As Integer
        Dim userexist As Boolean
        userexist = False
        'Load customization object

        cust = AuthenticationForm.tdc.Customization

        cust.Load()

        custusers = cust.Users

        For usercount = 0 To UsersToMove_list.Items.Count - 1
            username = LCase(UsersToMove_list.Items(usercount))
            custuser = custusers.user(username)

            If Not custuser.InGroup(CStr(ReadOnlyGroup)) Then

                custuser.AddToGroup(CStr(ReadOnlyGroup))
                If Err.Number <> 0 Then
                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]" & Err.Description & "."
                    LogText.Update()
                Else
                    LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "]" & " User [" & custuser.Name &
                            "] was added to group [" & ReadOnlyGroup & "] successfully."
                    LogText.Update()
                End If

            End If
        Next

        cust.Commit()
        Exit Sub
Exp:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub


    Private Sub RemoveUserFromProjectGroup()
        On Error Resume Next
        Dim usercount As Integer
        Dim SecondColumn() As String

        Dim cust As Object 'As Customization
        Dim custusers As Object ' As CustomizationUsers
        Dim custuser As Object ' As CustomizationUser
        Dim custGroups As Object ' As CustomizationUsersGroups
        Dim custGroup As Object ' As CustomizationUsersGroup
        Dim userInGrouplist As Object ' As List
        Dim i As Integer
        Dim loginUser As String
        Dim username As String

        'Load customization object
        cust = AuthenticationForm.tdc.Customization
        cust.Load()
        custGroups = cust.UsersGroups
        custusers = cust.Users
        loginUser = AuthenticationForm.tdc.username


        'Loop through each group
        For Each custGroup In custGroups.Groups
            'Ignore Viewer group
            If custGroup.Name <> ReadOnlyGroup Then
                'Get list of users in the group
                userInGrouplist = custGroup.userslist
                'If group is not empty then proceed
                If userInGrouplist.count <> 0 Then

                    'loop through users specified in excel file
                    For usercount = 0 To UsersToMove_list.Items.Count - 1
                        username = LCase(UsersToMove_list.Items(usercount))
                        custuser = custusers.user(username)
                        If custuser.InGroup(CStr(custGroup.Name)) Then
                                custuser.RemoveFromGroup(CStr(custGroup.name))
                            If Err.Number <> 0 Then
                                LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] Failed to remove User [" & custuser.Name & "] from group [" & custGroup.Name & "]."
                                LogText.Update()
                            Else
                                LogText.Text = LogText.Text & vbCrLf & "[" & AuthenticationForm.tdc.DomainName & ":" & AuthenticationForm.tdc.ProjectName & "] User [" & custuser.Name & "] was removed from group [" & custGroup.Name & "] successfully. "
                                LogText.Update()
                            End If
                        End If
                    Next
                End If
            End If
        Next
        cust.Commit()
        Exit Sub
Exp:
        LogText.Text = LogText.Text & vbCrLf & Err.Description
        LogText.Update()
    End Sub
End Class