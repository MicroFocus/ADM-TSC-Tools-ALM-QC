<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class AuthenticationForm
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents AuthenticateCommand As System.Windows.Forms.Button
    Public WithEvents RunCommand As System.Windows.Forms.Button
    Public WithEvents ProjectList As System.Windows.Forms.ListBox
    Public WithEvents DomainList As System.Windows.Forms.ListBox
    Public WithEvents SelectAllProjectCheck As System.Windows.Forms.CheckBox
    Public WithEvents SelectAllDomainCheck As System.Windows.Forms.CheckBox
    Public WithEvents SelectDomainCommand As System.Windows.Forms.Button
    Public WithEvents ServerUrlText As System.Windows.Forms.TextBox
    Public WithEvents UserPasswordText As System.Windows.Forms.TextBox
    Public WithEvents UserNameText As System.Windows.Forms.TextBox
    Public WithEvents SelectProjectCommand As System.Windows.Forms.Button
    Public WithEvents InitServCommand As System.Windows.Forms.Button
    Public WithEvents SubjectLabel As System.Windows.Forms.Label
    Public WithEvents StatusMessageLabel As System.Windows.Forms.Label
    Public WithEvents UserPasswordLabel As System.Windows.Forms.Label
    Public WithEvents UserNameLabel As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AuthenticationForm))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.TasksList = New System.Windows.Forms.ComboBox()
        Me.ProjectList = New System.Windows.Forms.ListBox()
        Me.DomainList = New System.Windows.Forms.ListBox()
        Me.SelectAllProjectCheck = New System.Windows.Forms.CheckBox()
        Me.SelectAllDomainCheck = New System.Windows.Forms.CheckBox()
        Me.ServerUrlText = New System.Windows.Forms.TextBox()
        Me.UserPasswordText = New System.Windows.Forms.TextBox()
        Me.UserNameText = New System.Windows.Forms.TextBox()
        Me.WorkingPath = New System.Windows.Forms.TextBox()
        Me.AuthenticateCommand = New System.Windows.Forms.Button()
        Me.RunCommand = New System.Windows.Forms.Button()
        Me.SelectDomainCommand = New System.Windows.Forms.Button()
        Me.SelectProjectCommand = New System.Windows.Forms.Button()
        Me.InitServCommand = New System.Windows.Forms.Button()
        Me.SubjectLabel = New System.Windows.Forms.Label()
        Me.StatusMessageLabel = New System.Windows.Forms.Label()
        Me.UserPasswordLabel = New System.Windows.Forms.Label()
        Me.UserNameLabel = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.APIKeyCheckbox = New System.Windows.Forms.CheckBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TasksList
        '
        Me.TasksList.BackColor = System.Drawing.Color.White
        Me.TasksList.FormattingEnabled = True
        Me.TasksList.Items.AddRange(New Object() {"Add Users to Projects", "List Users", "Move Users to Viewer Group", "Rename Users"})
        Me.TasksList.Location = New System.Drawing.Point(122, 409)
        Me.TasksList.Name = "TasksList"
        Me.TasksList.Size = New System.Drawing.Size(223, 22)
        Me.TasksList.Sorted = True
        Me.TasksList.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.TasksList, "Select a task")
        '
        'ProjectList
        '
        Me.ProjectList.BackColor = System.Drawing.SystemColors.Window
        Me.ProjectList.Cursor = System.Windows.Forms.Cursors.Default
        Me.ProjectList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProjectList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ProjectList.HorizontalScrollbar = True
        Me.ProjectList.ItemHeight = 14
        Me.ProjectList.Location = New System.Drawing.Point(120, 268)
        Me.ProjectList.Name = "ProjectList"
        Me.ProjectList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ProjectList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ProjectList.Size = New System.Drawing.Size(225, 116)
        Me.ProjectList.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.ProjectList, "Select project(s)")
        '
        'DomainList
        '
        Me.DomainList.BackColor = System.Drawing.SystemColors.Window
        Me.DomainList.Cursor = System.Windows.Forms.Cursors.Default
        Me.DomainList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DomainList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.DomainList.HorizontalScrollbar = True
        Me.DomainList.ItemHeight = 14
        Me.DomainList.Location = New System.Drawing.Point(122, 123)
        Me.DomainList.Name = "DomainList"
        Me.DomainList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DomainList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.DomainList.Size = New System.Drawing.Size(223, 116)
        Me.DomainList.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.DomainList, "Select domain(s)")
        '
        'SelectAllProjectCheck
        '
        Me.SelectAllProjectCheck.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.SelectAllProjectCheck.Cursor = System.Windows.Forms.Cursors.Default
        Me.SelectAllProjectCheck.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SelectAllProjectCheck.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SelectAllProjectCheck.Location = New System.Drawing.Point(378, 323)
        Me.SelectAllProjectCheck.Name = "SelectAllProjectCheck"
        Me.SelectAllProjectCheck.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SelectAllProjectCheck.Size = New System.Drawing.Size(97, 17)
        Me.SelectAllProjectCheck.TabIndex = 10
        Me.SelectAllProjectCheck.Text = "All Projects"
        Me.ToolTip1.SetToolTip(Me.SelectAllProjectCheck, "Select all projects")
        Me.SelectAllProjectCheck.UseVisualStyleBackColor = False
        '
        'SelectAllDomainCheck
        '
        Me.SelectAllDomainCheck.BackColor = System.Drawing.SystemColors.HighlightText
        Me.SelectAllDomainCheck.Cursor = System.Windows.Forms.Cursors.Default
        Me.SelectAllDomainCheck.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SelectAllDomainCheck.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SelectAllDomainCheck.Location = New System.Drawing.Point(378, 186)
        Me.SelectAllDomainCheck.Name = "SelectAllDomainCheck"
        Me.SelectAllDomainCheck.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SelectAllDomainCheck.Size = New System.Drawing.Size(97, 17)
        Me.SelectAllDomainCheck.TabIndex = 7
        Me.SelectAllDomainCheck.Text = "All Domains"
        Me.ToolTip1.SetToolTip(Me.SelectAllDomainCheck, "Select all domains")
        Me.SelectAllDomainCheck.UseVisualStyleBackColor = False
        '
        'ServerUrlText
        '
        Me.ServerUrlText.AcceptsReturn = True
        Me.ServerUrlText.BackColor = System.Drawing.SystemColors.Window
        Me.ServerUrlText.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ServerUrlText.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ServerUrlText.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ServerUrlText.Location = New System.Drawing.Point(120, 16)
        Me.ServerUrlText.MaxLength = 0
        Me.ServerUrlText.Name = "ServerUrlText"
        Me.ServerUrlText.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ServerUrlText.Size = New System.Drawing.Size(227, 20)
        Me.ServerUrlText.TabIndex = 0
        Me.ServerUrlText.Text = "https://<server>/qcbin"
        Me.ToolTip1.SetToolTip(Me.ServerUrlText, "Enter URL")
        '
        'UserPasswordText
        '
        Me.UserPasswordText.AcceptsReturn = True
        Me.UserPasswordText.BackColor = System.Drawing.SystemColors.Window
        Me.UserPasswordText.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.UserPasswordText.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserPasswordText.ForeColor = System.Drawing.SystemColors.WindowText
        Me.UserPasswordText.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.UserPasswordText.Location = New System.Drawing.Point(122, 89)
        Me.UserPasswordText.MaxLength = 0
        Me.UserPasswordText.Name = "UserPasswordText"
        Me.UserPasswordText.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.UserPasswordText.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.UserPasswordText.Size = New System.Drawing.Size(223, 20)
        Me.UserPasswordText.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.UserPasswordText, "Enter password")
        '
        'UserNameText
        '
        Me.UserNameText.AcceptsReturn = True
        Me.UserNameText.BackColor = System.Drawing.SystemColors.Window
        Me.UserNameText.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.UserNameText.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserNameText.ForeColor = System.Drawing.SystemColors.WindowText
        Me.UserNameText.Location = New System.Drawing.Point(120, 56)
        Me.UserNameText.MaxLength = 0
        Me.UserNameText.Name = "UserNameText"
        Me.UserNameText.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.UserNameText.Size = New System.Drawing.Size(225, 20)
        Me.UserNameText.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.UserNameText, "Enter user name")
        '
        'WorkingPath
        '
        Me.WorkingPath.BackColor = System.Drawing.Color.White
        Me.WorkingPath.Location = New System.Drawing.Point(120, 453)
        Me.WorkingPath.Name = "WorkingPath"
        Me.WorkingPath.Size = New System.Drawing.Size(225, 20)
        Me.WorkingPath.TabIndex = 13
        Me.WorkingPath.Text = "c:\temp\SaaSToolKit"
        Me.ToolTip1.SetToolTip(Me.WorkingPath, "Working directory")
        '
        'AuthenticateCommand
        '
        Me.AuthenticateCommand.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.AuthenticateCommand.Cursor = System.Windows.Forms.Cursors.Default
        Me.AuthenticateCommand.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AuthenticateCommand.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AuthenticateCommand.Location = New System.Drawing.Point(378, 79)
        Me.AuthenticateCommand.Name = "AuthenticateCommand"
        Me.AuthenticateCommand.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AuthenticateCommand.Size = New System.Drawing.Size(113, 30)
        Me.AuthenticateCommand.TabIndex = 4
        Me.AuthenticateCommand.Text = "Authenticate"
        Me.AuthenticateCommand.UseVisualStyleBackColor = False
        '
        'RunCommand
        '
        Me.RunCommand.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.RunCommand.Cursor = System.Windows.Forms.Cursors.Default
        Me.RunCommand.Enabled = False
        Me.RunCommand.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RunCommand.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RunCommand.Location = New System.Drawing.Point(386, 403)
        Me.RunCommand.Name = "RunCommand"
        Me.RunCommand.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RunCommand.Size = New System.Drawing.Size(105, 30)
        Me.RunCommand.TabIndex = 12
        Me.RunCommand.Text = "Run"
        Me.RunCommand.UseVisualStyleBackColor = False
        '
        'SelectDomainCommand
        '
        Me.SelectDomainCommand.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.SelectDomainCommand.Cursor = System.Windows.Forms.Cursors.Default
        Me.SelectDomainCommand.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SelectDomainCommand.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SelectDomainCommand.Location = New System.Drawing.Point(378, 123)
        Me.SelectDomainCommand.Name = "SelectDomainCommand"
        Me.SelectDomainCommand.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SelectDomainCommand.Size = New System.Drawing.Size(105, 30)
        Me.SelectDomainCommand.TabIndex = 6
        Me.SelectDomainCommand.Text = "Select Domain"
        Me.SelectDomainCommand.UseVisualStyleBackColor = False
        '
        'SelectProjectCommand
        '
        Me.SelectProjectCommand.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.SelectProjectCommand.Cursor = System.Windows.Forms.Cursors.Default
        Me.SelectProjectCommand.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SelectProjectCommand.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SelectProjectCommand.Location = New System.Drawing.Point(378, 268)
        Me.SelectProjectCommand.Name = "SelectProjectCommand"
        Me.SelectProjectCommand.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SelectProjectCommand.Size = New System.Drawing.Size(105, 30)
        Me.SelectProjectCommand.TabIndex = 9
        Me.SelectProjectCommand.Text = "Select Project"
        Me.SelectProjectCommand.UseVisualStyleBackColor = False
        '
        'InitServCommand
        '
        Me.InitServCommand.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.InitServCommand.Cursor = System.Windows.Forms.Cursors.Default
        Me.InitServCommand.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InitServCommand.ForeColor = System.Drawing.SystemColors.ControlText
        Me.InitServCommand.Location = New System.Drawing.Point(378, 16)
        Me.InitServCommand.Name = "InitServCommand"
        Me.InitServCommand.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.InitServCommand.Size = New System.Drawing.Size(113, 30)
        Me.InitServCommand.TabIndex = 1
        Me.InitServCommand.Text = "Initialize Server"
        Me.InitServCommand.UseVisualStyleBackColor = False
        '
        'SubjectLabel
        '
        Me.SubjectLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.SubjectLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.SubjectLabel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SubjectLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SubjectLabel.Location = New System.Drawing.Point(21, 409)
        Me.SubjectLabel.Name = "SubjectLabel"
        Me.SubjectLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SubjectLabel.Size = New System.Drawing.Size(85, 33)
        Me.SubjectLabel.TabIndex = 19
        Me.SubjectLabel.Text = "Select Task :"
        '
        'StatusMessageLabel
        '
        Me.StatusMessageLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.StatusMessageLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.StatusMessageLabel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusMessageLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.StatusMessageLabel.Location = New System.Drawing.Point(21, 484)
        Me.StatusMessageLabel.Name = "StatusMessageLabel"
        Me.StatusMessageLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StatusMessageLabel.Size = New System.Drawing.Size(310, 17)
        Me.StatusMessageLabel.TabIndex = 21
        Me.StatusMessageLabel.Text = "Ready."
        '
        'UserPasswordLabel
        '
        Me.UserPasswordLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.UserPasswordLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.UserPasswordLabel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserPasswordLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.UserPasswordLabel.Location = New System.Drawing.Point(21, 92)
        Me.UserPasswordLabel.Name = "UserPasswordLabel"
        Me.UserPasswordLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.UserPasswordLabel.Size = New System.Drawing.Size(85, 17)
        Me.UserPasswordLabel.TabIndex = 16
        Me.UserPasswordLabel.Text = "Password:"
        '
        'UserNameLabel
        '
        Me.UserNameLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.UserNameLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.UserNameLabel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserNameLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.UserNameLabel.Location = New System.Drawing.Point(21, 56)
        Me.UserNameLabel.Name = "UserNameLabel"
        Me.UserNameLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.UserNameLabel.Size = New System.Drawing.Size(63, 17)
        Me.UserNameLabel.TabIndex = 15
        Me.UserNameLabel.Text = "User Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 14)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Server URL:"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Image = Global.SaaSToolKit.My.Resources.Resources.logo2
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(356, 453)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(135, 54)
        Me.PictureBox1.TabIndex = 25
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 453)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 14)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Log Path:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 123)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 14)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Domain:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(21, 253)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 14)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Project:"
        '
        'APIKeyCheckbox
        '
        Me.APIKeyCheckbox.AutoSize = True
        Me.APIKeyCheckbox.Location = New System.Drawing.Point(378, 56)
        Me.APIKeyCheckbox.Name = "APIKeyCheckbox"
        Me.APIKeyCheckbox.Size = New System.Drawing.Size(64, 18)
        Me.APIKeyCheckbox.TabIndex = 26
        Me.APIKeyCheckbox.Text = "API Key"
        Me.APIKeyCheckbox.UseVisualStyleBackColor = True
        '
        'AuthenticationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(503, 533)
        Me.Controls.Add(Me.APIKeyCheckbox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.WorkingPath)
        Me.Controls.Add(Me.TasksList)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.AuthenticateCommand)
        Me.Controls.Add(Me.RunCommand)
        Me.Controls.Add(Me.ProjectList)
        Me.Controls.Add(Me.DomainList)
        Me.Controls.Add(Me.SelectAllProjectCheck)
        Me.Controls.Add(Me.SelectAllDomainCheck)
        Me.Controls.Add(Me.SelectDomainCommand)
        Me.Controls.Add(Me.ServerUrlText)
        Me.Controls.Add(Me.UserPasswordText)
        Me.Controls.Add(Me.UserNameText)
        Me.Controls.Add(Me.SelectProjectCommand)
        Me.Controls.Add(Me.InitServCommand)
        Me.Controls.Add(Me.SubjectLabel)
        Me.Controls.Add(Me.StatusMessageLabel)
        Me.Controls.Add(Me.UserPasswordLabel)
        Me.Controls.Add(Me.UserNameLabel)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(9, 28)
        Me.MaximizeBox = False
        Me.Name = "AuthenticationForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "SaaS Toolkit"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TasksList As System.Windows.Forms.ComboBox
    Friend WithEvents WorkingPath As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents APIKeyCheckbox As CheckBox
#End Region
End Class